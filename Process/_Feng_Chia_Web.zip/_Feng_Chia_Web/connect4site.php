<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>逢甲大玩客 - 會員註冊</title>
  <link rel="stylesheet" type="text/css" href="css/login.css">
  <link rel="stylesheet" type="text/css" href="css/menu.css">
  <link rel="stylesheet" type="text/css" href="css/goto.css">
</head>

<body>
    <div align="center" id="back_index" style="height: 800px; border-radius:20%;">
      <span style="color: white;">選擇目錄</span>
        <div>
            <a href = "page_food.php"><div class = "four_block_back" id = "four_block_01" style = "background-image: url(img/four_block_1.png); background-repeat:no-repeat;background-size:250px ;"><div class = "four_block_front">食</div></div></a>
            <a href = "page_dress.php"><div class = "four_block_back" id = "four_block_02" style = "background-image: url(img/four_block_2.png); background-repeat:no-repeat;background-size:250px ;"><div class = "four_block_front">衣</div></div></a>
            <a href = "http://www.trivago.com.tw/?cpt=324044602&r=&iRoomType=7&aHotelTestClassifier=&iIncludeAll=0&iGeoDistanceLimit=20000&aPartner=&iGeoDistanceItem=3240446&iPathId=408051&aDateRange%5Barr%5D=2016-07-24&aDateRange%5Bdep%5D=2016-07-25&iViewType=0&bIsSeoPage=false&bIsSitemap=false&"><div class = "four_block_back" id = "four_block_03" style = "background-image: url(img/four_block_3.png); background-repeat:no-repeat;background-size:250px ;"><div class = "four_block_front">住</div></div></a>
            <a href = "http://citybus.taichung.gov.tw/iTravel/"><div class = "four_block_back" id = "four_block_04" style = "background-image: url(img/four_block_4.png); background-repeat:no-repeat;background-size:300px ;"><div class = "four_block_front">行</div></div></a>
        </div>
    </div>
  </div>
  
</body>
</html>